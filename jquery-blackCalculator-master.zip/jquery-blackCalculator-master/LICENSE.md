blackCalculator 1.0
© Copyright 2012 Rafael Carvalho Oliveira - http://www.blackhauz.com.br/

============================== License ==================================
Dual licensed under the MIT or GPL Version 2 licenses
